#!/usr/bin/env python3
from pathlib import Path
import zipfile, subprocess, shutil, sys

src = Path(__file__).resolve().parent
work = Path("/tmp/tnypl-v122-combined")

if work.exists():
    shutil.rmtree(work)
(work / "baseline").mkdir(parents=True)
(work / "profiles").mkdir(parents=True)

baseline_zip = src / "TNYPL_Combined_Sponsor_Senthil_Email_Fix_v1_2_1.zip"
profiles_zip = src / "TNYPL_Leadership_Owner_Text_Enhancement_v1_2_0.zip"

with zipfile.ZipFile(baseline_zip) as z:
    z.extractall(work / "baseline")

with zipfile.ZipFile(profiles_zip) as z:
    z.extractall(work / "profiles")

baseline_script = work / "baseline" / "apply-combined-fix.py"
profile_script = work / "profiles" / "apply-profile-text-enhancement.py"

if not baseline_script.exists():
    sys.exit("ERROR: baseline apply script not found.")
if not profile_script.exists():
    sys.exit("ERROR: profile enhancement apply script not found.")

print("STEP 1/2: Applying established baseline...")
subprocess.run([sys.executable, str(baseline_script)], check=True)

print("\nSTEP 2/2: Applying leadership and owner profile enhancements...")
subprocess.run([sys.executable, str(profile_script)], check=True)

print("\nPASS: v1.2.2 combined baseline + profile enhancement applied.")
print("Baseline preserved: Cricket5 sponsor, Senthil photo, info@tnypl.in cleanup.")
print("Enhanced: leadership/admin profiles and founding-owner profile text.")
