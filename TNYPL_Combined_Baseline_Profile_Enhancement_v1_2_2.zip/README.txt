TNYPL Combined Baseline + Profile Enhancement v1.2.2

This package intentionally uses the previously approved combined baseline as its
foundation:

TNYPL_Combined_Sponsor_Senthil_Email_Fix_v1_2_1.zip

Then it applies the text-only profile enhancement:

TNYPL_Leadership_Owner_Text_Enhancement_v1_2_0.zip

So you retain:
- the exact Senthil Narayanan photo you supplied
- the exact Cricket5 Crickets Academy sponsor logo you supplied
- Cricket5 sponsor placement
- info@tnypl.in official email cleanup
- duplicate homepage footer removal
- the Cricket5 Supabase sponsor query

And you also get richer content for:
- Dinesh Devadoss
- Senthil Narayanan
- Ranjith Janagiraman
- Ajay Manohar
- Leadership landing page
- Owners landing page
- Vimalesh Vedachalam
- Gopi Ramadoss
- Porkai Pandian Gopalakrishnan
- Satish Raja
- Ramanathan Periyaraja
- P. C. Binny Jo
- Thanjavur Royals co-owners
- Tuticorin Sharks co-owners

The profile enhancement does not change photographs.

DEPLOY

git checkout main
git pull origin main
git checkout -b release/v1.2.2-combined-profile-enhancement

rm -rf /tmp/tnypl-v122
mkdir -p /tmp/tnypl-v122

unzip -o TNYPL_Combined_Baseline_Profile_Enhancement_v1_2_2.zip -d /tmp/tnypl-v122

python3 /tmp/tnypl-v122/apply-v1.2.2.py

REVIEW

git status

git diff --   index.html   sponsors.js   config.js   leadership.html   dinesh-devadoss.html   senthil-narayanan.html   ranjith-janagiraman.html   ajay-manohar.html   owners.html   vimalesh-vedachalam.html   gopi-ramadoss.html   porkai-pandian.html   satish-raja.html   ramanathan-periyaraja.html   pc-binny-jo.html   thanjavur-royals-owners.html   tuticorin-sharks-owners.html   styles.css

VERIFY OLD OFFICIAL EMAILS

grep -Rni --exclude-dir=.git --exclude-dir=node_modules --exclude="*.zip"   -E "ttnypl@gmail.com|tnypl@gmail.com" .

Expected: no old official TNYPL email references.

VERIFY SENTHIL PHOTO

grep -n "senthil-narayanan.png" leadership.html senthil-narayanan.html

VERIFY CRICKET5

grep -n "Cricket5 Crickets Academy" index.html sponsors.js

VERIFY FOOTER

grep -n "<footer" index.html

Expected: one homepage footer.

SUPABASE

The baseline package contains TNYPL_CRICKET5_SPONSOR.sql.
Run it if Cricket5 is not already present in the sponsors table.

COMMIT

git add -A

git commit -m "Enhance leadership and owner profiles on combined baseline"

git push -u origin release/v1.2.2-combined-profile-enhancement
