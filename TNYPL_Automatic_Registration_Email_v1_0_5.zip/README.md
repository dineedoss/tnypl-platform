# TNYPL Automatic Registration Confirmation Emails v1.0.5

This automates confirmation emails without changing the working registration flow.

Flow remains:
1. Player registers normally.
2. Supabase saves the player immediately.
3. Netlify scheduled function checks once per minute for unsent confirmations.
4. Resend sends the email separately.
5. If Resend fails, registration remains successful and the email retries later.

The existing Admin "Send Pending Registration Emails" button can remain as a backup.

Required Netlify variables:
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY
- RESEND_API_KEY
- EMAIL_FROM

Deploy:

git checkout main
git pull origin main
git checkout -b hotfix/automatic-registration-email

rm -rf /tmp/tnypl-auto-email
mkdir -p /tmp/tnypl-auto-email

unzip -o TNYPL_Automatic_Registration_Email_v1_0_5.zip -d /tmp/tnypl-auto-email

Run TNYPL_AUTO_REGISTRATION_EMAIL_v1_0_5.sql in Supabase SQL Editor.

python3 /tmp/tnypl-auto-email/apply-auto-email.py

node --check netlify/functions/auto-registration-emails.mjs
git diff -- netlify.toml netlify/functions/auto-registration-emails.mjs

git add netlify.toml netlify/functions/auto-registration-emails.mjs
git commit -m "Automate player registration confirmation emails"
git push -u origin hotfix/automatic-registration-email

Testing:
Netlify scheduled functions do not automatically fire on branch previews.
After deploying the branch, go to Netlify > Functions >
auto-registration-emails > Run now.

Then verify:

select
  full_name,
  email,
  created_at,
  registration_email_sent_at,
  registration_email_claimed_at
from public.players
order by created_at desc
limit 20;

Once merged to production, it runs every minute automatically.
