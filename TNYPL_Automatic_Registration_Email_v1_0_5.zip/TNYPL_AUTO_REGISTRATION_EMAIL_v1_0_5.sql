-- TNYPL Automatic Registration Email v1.0.5
-- Does NOT change public registration insert flow or RLS policies.

alter table public.players
add column if not exists registration_email_claimed_at timestamptz;

create index if not exists players_registration_email_pending_idx
on public.players (created_at)
where registration_email_sent_at is null;

comment on column public.players.registration_email_claimed_at is
'Temporary server-side claim used by the automatic registration confirmation email worker.';

notify pgrst, 'reload schema';

select column_name, data_type
from information_schema.columns
where table_schema='public'
  and table_name='players'
  and column_name in ('registration_email_sent_at','registration_email_claimed_at')
order by column_name;
