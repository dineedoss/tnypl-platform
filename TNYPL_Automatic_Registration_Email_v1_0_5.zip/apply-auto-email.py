#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

src = Path(__file__).resolve().parent
if not Path("netlify.toml").exists():
    sys.exit("ERROR: netlify.toml not found. Run from repository root.")

target = Path("netlify/functions/auto-registration-emails.mjs")
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(src / "netlify/functions/auto-registration-emails.mjs", target)

toml = Path("netlify.toml")
text = toml.read_text(encoding="utf-8")

schedule_block = '''
# TNYPL automatic player-registration confirmation emails.
[functions."auto-registration-emails"]
  schedule = "* * * * *"
'''

if '[functions."auto-registration-emails"]' not in text:
    toml.write_text(text.rstrip() + "\n\n" + schedule_block + "\n", encoding="utf-8")

print("PASS: Automatic registration email worker installed.")
print("Public registration app.js/index.html were NOT changed.")
