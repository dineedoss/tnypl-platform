TNYPL Combined Sponsor + Senthil Photo + Official Email Fix v1.2.1

This package combines:
1. Cricket5 Crickets Academy sponsor logo
2. Senthil Narayanan photograph
3. Official email standardized to info@tnypl.in
4. Removal of the obsolete duplicate homepage footer

It replaces ONLY the historical official addresses:
- tnypl@gmail.com
- ttnypl@gmail.com

It does NOT replace owner login emails or player emails.

It also repairs malformed source text like:
[info@tnypl.in](mailto:info@tnypl.in)
to the clean value:
info@tnypl.in

DEPLOY

git checkout main
git pull origin main
git checkout -b hotfix/combined-sponsor-senthil-email

rm -rf /tmp/tnypl-combined-fix
mkdir -p /tmp/tnypl-combined-fix

unzip -o TNYPL_Combined_Sponsor_Senthil_Email_Fix_v1_2_1.zip -d /tmp/tnypl-combined-fix

python3 /tmp/tnypl-combined-fix/apply-combined-fix.py

REVIEW

git status

git diff -- index.html sponsors.js leadership.html senthil-narayanan.html styles.css config.js

VERIFY EMAILS

grep -Rni --exclude-dir=.git --exclude-dir=node_modules --exclude="*.zip" -E "ttnypl@gmail.com|tnypl@gmail.com" .

Expected: no output for the two old official addresses.

VERIFY SENTHIL PHOTO

grep -n "senthil-narayanan.png" leadership.html senthil-narayanan.html

VERIFY SPONSOR

grep -n "Cricket5 Crickets Academy" index.html sponsors.js

VERIFY FOOTER

grep -n "<footer" index.html

Expected: one homepage footer.

SUPABASE

Run TNYPL_CRICKET5_SPONSOR.sql if the Sponsors page is database-backed.

COMMIT

git add -A
git commit -m "Combine Cricket5 sponsor Senthil photo and official email fixes"
git push -u origin hotfix/combined-sponsor-senthil-email
