#!/usr/bin/env python3
from pathlib import Path
import shutil, re, sys, json

src = Path(__file__).resolve().parent
cfg = json.loads((src / "patch-config.json").read_text(encoding="utf-8"))

required = ["index.html","sponsors.js","leadership.html","senthil-narayanan.html","styles.css","config.js"]
missing = [f for f in required if not Path(f).exists()]
if missing:
    sys.exit("ERROR: Run from repository root. Missing: " + ", ".join(missing))

# Copy supplied image assets.
Path("assets/profiles").mkdir(parents=True, exist_ok=True)
shutil.copy2(src / "sponsor-cricket5.png", "sponsor-cricket5.png")
shutil.copy2(src / "assets/profiles/senthil-narayanan.png", "assets/profiles/senthil-narayanan.png")

# Standardize only the two official TNYPL Gmail addresses and clean malformed markdown.
extensions = {".html",".js",".mjs",".css",".md",".txt",".json",".sql"}
email_updated = []

for f in Path(".").rglob("*"):
    if not f.is_file() or ".git" in f.parts or "node_modules" in f.parts:
        continue
    if f.suffix.lower() not in extensions:
        continue
    try:
        s = f.read_text(encoding="utf-8")
    except Exception:
        continue

    old = s
    s = s.replace("[info@tnypl.in](mailto\\:info@tnypl.in)", "info@tnypl.in")
    s = s.replace("[info@tnypl.in](mailto:info@tnypl.in)", "info@tnypl.in")
    s = re.sub(r'(?i)\bttnypl@gmail\.com\b', 'info@tnypl.in', s)
    s = re.sub(r'(?i)\btnypl@gmail\.com\b', 'info@tnypl.in', s)

    if s != old:
        f.write_text(s, encoding="utf-8")
        email_updated.append(str(f))

# Force clean config CONTACT_EMAIL value.
p = Path("config.js")
s = p.read_text(encoding="utf-8")
if re.search(r'CONTACT_EMAIL\s*:', s):
    s = re.sub(
        r'CONTACT_EMAIL\s*:\s*["\'][^"\']*["\']\s*,?',
        'CONTACT_EMAIL: "info@tnypl.in",',
        s,
        count=1
    )
else:
    marker = "window.TNYPL_CONFIG = {\n"
    if marker not in s:
        sys.exit("ERROR: TNYPL_CONFIG block not found.")
    s = s.replace(marker, marker + '  CONTACT_EMAIL: "info@tnypl.in",\n', 1)
p.write_text(s, encoding="utf-8")

# Homepage: remove obsolete duplicate inline footer.
p = Path("index.html")
s = p.read_text(encoding="utf-8")
dup = re.compile(
    r'<footer style="background:#020b18;color:#9fb0c5;padding:28px;text-align:center;'
    r'font-family:Inter,Arial,sans-serif">.*?</footer>\s*',
    re.S
)
s, footer_removed = dup.subn("", s, count=1)

# Homepage: add Cricket5 partner card.
if "Cricket5 Crickets Academy" not in s:
    marker = cfg["homepage_partner_marker"]
    if marker not in s:
        sys.exit("ERROR: Homepage sponsor insertion point not found.")
    s = s.replace(marker, cfg["homepage_partner_block"] + marker, 1)
p.write_text(s, encoding="utf-8")

# Sponsors fallback.
p = Path("sponsors.js")
s = p.read_text(encoding="utf-8")
if 'name:"Cricket5 Crickets Academy"' not in s:
    marker = cfg["sponsors_marker"]
    if marker not in s:
        sys.exit("ERROR: sponsors.js insertion point not found.")
    s = s.replace(
        marker,
        marker + ',\n {name:"Cricket5 Crickets Academy",logo_path:"sponsor-cricket5.png"}',
        1
    )
p.write_text(s, encoding="utf-8")

# Senthil photo in leadership directory.
p = Path("leadership.html")
s = p.read_text(encoding="utf-8")
if cfg["leadership_old"] in s:
    s = s.replace(cfg["leadership_old"], cfg["leadership_new"], 1)
p.write_text(s, encoding="utf-8")

# Senthil profile hero photo.
p = Path("senthil-narayanan.html")
s = p.read_text(encoding="utf-8")
if cfg["senthil_old"] in s:
    s = s.replace(cfg["senthil_old"], cfg["senthil_new"], 1)
p.write_text(s, encoding="utf-8")

# Sponsor logo sizing.
p = Path("styles.css")
s = p.read_text(encoding="utf-8")
if ".partner-card-logo img" not in s:
    s += """
.partner-card-logo img{
  display:block;
  width:min(220px,90%);
  height:88px;
  object-fit:contain;
  margin:0 auto 12px;
  background:#fff;
  border-radius:10px;
  padding:8px;
}
"""
p.write_text(s, encoding="utf-8")

# Verification.
index_text = Path("index.html").read_text(encoding="utf-8")
lead_text = Path("leadership.html").read_text(encoding="utf-8")
senthil_text = Path("senthil-narayanan.html").read_text(encoding="utf-8")
config_text = Path("config.js").read_text(encoding="utf-8")

checks = [
    ("official homepage email", "info@tnypl.in" in index_text),
    ("old official Gmail removed from homepage", "tnypl@gmail.com" not in index_text.lower() and "ttnypl@gmail.com" not in index_text.lower()),
    ("single homepage footer", index_text.count("<footer") == 1),
    ("Cricket5 homepage partner", "Cricket5 Crickets Academy" in index_text),
    ("Senthil leadership photo", "assets/profiles/senthil-narayanan.png" in lead_text),
    ("Senthil profile photo", "assets/profiles/senthil-narayanan.png" in senthil_text),
    ("config contact email", 'CONTACT_EMAIL: "info@tnypl.in"' in config_text),
]

failed = [name for name, ok in checks if not ok]
if failed:
    print("WARNING: Verification issues:")
    for name in failed:
        print(" -", name)
else:
    print("PASS: All combined release checks passed.")

print(f"Official email references updated in {len(email_updated)} file(s).")
print(f"Duplicate homepage footer removed: {footer_removed == 1}")
print("PASS: Cricket5 sponsor, Senthil photo and info@tnypl.in cleanup applied.")
