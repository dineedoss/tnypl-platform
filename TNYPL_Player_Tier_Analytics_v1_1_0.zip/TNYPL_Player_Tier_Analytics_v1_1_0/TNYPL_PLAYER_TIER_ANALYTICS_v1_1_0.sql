alter table public.players add column if not exists player_tier text;
alter table public.players add column if not exists suggested_tier text;
alter table public.players add column if not exists cricheroes_score numeric(5,2);
alter table public.players add column if not exists overall_player_score numeric(5,2);
alter table public.players add column if not exists tier_override boolean not null default false;
alter table public.players add column if not exists tier_updated_at timestamptz;
alter table public.players add column if not exists cricheroes_matches integer;
alter table public.players add column if not exists cricheroes_runs integer;
alter table public.players add column if not exists cricheroes_batting_average numeric(7,2);
alter table public.players add column if not exists cricheroes_strike_rate numeric(7,2);
alter table public.players add column if not exists cricheroes_wickets integer;
alter table public.players add column if not exists cricheroes_economy numeric(7,2);
alter table public.players add column if not exists cricheroes_bowling_average numeric(7,2);
alter table public.players add column if not exists cricheroes_dismissals integer;
alter table public.players add column if not exists cricheroes_recent_form_score numeric(5,2);
alter table public.players add column if not exists cricheroes_extraction_confidence numeric(5,2);
alter table public.players add column if not exists cricheroes_analyzed_at timestamptz;
alter table public.players add column if not exists coach_technique_score numeric(5,2);
alter table public.players add column if not exists coach_awareness_score numeric(5,2);
alter table public.players add column if not exists coach_fielding_score numeric(5,2);
alter table public.players add column if not exists coach_temperament_score numeric(5,2);
alter table public.players add column if not exists coach_role_fit_score numeric(5,2);
alter table public.players add column if not exists coach_review_score numeric(5,2);

alter table public.players drop constraint if exists players_player_tier_check;
alter table public.players add constraint players_player_tier_check
check (player_tier is null or player_tier in ('platinum','gold','silver','review'));

alter table public.players drop constraint if exists players_suggested_tier_check;
alter table public.players add constraint players_suggested_tier_check
check (suggested_tier is null or suggested_tier in ('platinum','gold','silver','review'));

create index if not exists players_player_tier_idx on public.players(player_tier);
notify pgrst, 'reload schema';