TNYPL Player Tier Analytics v1.1.0

Adds Suggested Tier, Score, CricHeroes analysis, coach review, editable Final Tier, tier filters and admin override.
Public registration app.js/index.html are NOT modified.

DEPLOY

git checkout main
git pull origin main
git checkout -b release/v1.1-player-tier-analytics

rm -rf /tmp/tnypl-tier
mkdir -p /tmp/tnypl-tier
unzip -o TNYPL_Player_Tier_Analytics_v1_1_0.zip -d /tmp/tnypl-tier

Run TNYPL_PLAYER_TIER_ANALYTICS_v1_1_0.sql in Supabase SQL Editor.

python3 /tmp/tnypl-tier/apply-player-tier-release.py

node --check admin.js
node --check admin-player-tier.js
node --check player-tier-engine.js
node --check netlify/functions/analyze-cricheroes.js

git diff -- admin.html admin.js
git status

git add admin.html admin.js admin-player-tier.js player-tier-engine.js netlify/functions/analyze-cricheroes.js
git commit -m "Add player tier analytics and selector override"
git push -u origin release/v1.1-player-tier-analytics

TEST
1. Admin > Player Registrations.
2. Click Analyze next to a player.
3. Click Analyze CricHeroes.
4. Review/edit extracted stats.
5. Click Calculate Suggested Tier.
6. Confirm Final Tier defaults to suggestion.
7. Override if needed and Save.
8. Verify tier and score in list.
