#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

src=Path(__file__).resolve().parent
for f in ['admin.html','admin.js']:
    if not Path(f).exists():
        sys.exit(f'ERROR: {f} not found. Run from repository root.')

Path('netlify/functions').mkdir(parents=True,exist_ok=True)
for rel in ['player-tier-engine.js','admin-player-tier.js','netlify/functions/analyze-cricheroes.js']:
    dst=Path(rel)
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src/rel,dst)

p=Path('admin.html')
html=p.read_text(encoding='utf-8')
html=html.replace('<select id="statusFilter" style="padding:12px"><option value="">All statuses</option>', '<select id="tierFilter" style="padding:12px"><option value="">All tiers</option><option value="platinum">Platinum</option><option value="gold">Gold</option><option value="silver">Silver</option><option value="review">Review</option><option value="unclassified">Unclassified</option></select><select id="statusFilter" style="padding:12px"><option value="">All statuses</option>',1)
html=html.replace('<th>Status</th><th>Franchise</th><th>Actions</th>', '<th>Status</th><th>Tier</th><th>Score</th><th>Franchise</th><th>Actions</th>',1)

modal = '''<div id="tierModal" hidden style="position:fixed;inset:0;background:rgba(2,12,30,.82);z-index:9999;overflow:auto;padding:30px">
<div style="width:min(920px,100%);margin:20px auto;background:white;border-radius:18px;padding:26px;color:#06132a">
<div style="display:flex;justify-content:space-between;gap:20px"><div><small style="font-weight:900;color:#9b6d0a">PLAYER ANALYTICS</small><h2 id="tierPlayerName">Player</h2><div id="tierRole"></div></div><button id="closeTierModal" class="button outline">Close</button></div>
<p id="tierMessage" style="padding:10px;background:#f5f7fa"></p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px">
<label>Matches<input id="tierMatches" type="number"></label><label>Runs<input id="tierRuns" type="number"></label><label>Bat Avg<input id="tierBatAvg" type="number" step=".01"></label><label>Strike Rate<input id="tierSR" type="number" step=".01"></label><label>Wickets<input id="tierWickets" type="number"></label><label>Economy<input id="tierEconomy" type="number" step=".01"></label><label>Bowling Avg<input id="tierBowlAvg" type="number" step=".01"></label><label>WK Dismissals<input id="tierDismissals" type="number"></label><label>Recent Form /10<input id="tierRecent" type="number" min="0" max="10" step=".5"></label><label>Extraction %<input id="tierConfidence" type="number" readonly></label>
</div>
<div style="display:flex;gap:10px;flex-wrap:wrap;margin:18px 0"><button id="analyzeCricHeroesBtn" class="button gold">Analyze CricHeroes</button><button id="calculateTierBtn" class="button gold">Calculate Suggested Tier</button></div>
<h3>Coach Review /30 (optional)</h3>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px"><label>Technique /10<input id="coachTechnique" type="number" min="0" max="10" step=".5"></label><label>Awareness /5<input id="coachAwareness" type="number" min="0" max="5" step=".5"></label><label>Fielding /5<input id="coachFielding" type="number" min="0" max="5" step=".5"></label><label>Temperament /5<input id="coachTemperament" type="number" min="0" max="5" step=".5"></label><label>Role Fit /5<input id="coachRoleFit" type="number" min="0" max="5" step=".5"></label></div>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0"><div style="background:#f5f7fa;padding:15px">CricHeroes<strong id="tierProfileScore" style="display:block;font-size:2rem">-</strong></div><div style="background:#f5f7fa;padding:15px">Overall<strong id="tierOverallScore" style="display:block;font-size:2rem">-</strong></div><div style="background:#f5f7fa;padding:15px">Suggested<strong id="tierSuggested" style="display:block;font-size:2rem">-</strong></div></div>
<label>Final Tier<select id="tierFinal" style="width:100%;padding:12px"><option value="">Unclassified</option><option value="platinum">Platinum</option><option value="gold">Gold</option><option value="silver">Silver</option><option value="review">Review Required</option></select></label>
<div style="margin-top:16px"><button id="saveTierBtn" class="button gold">Save Final Tier</button></div>
</div></div>'''
if 'id="tierModal"' not in html:
    html=html.replace('</main>','</main>'+modal,1)
html=html.replace('<script src="config.js"></script><script src="admin.js"></script>', '<script src="config.js"></script><script src="player-tier-engine.js?v=1.1.0"></script><script src="admin.js"></script><script src="admin-player-tier.js?v=1.1.0"></script>',1)
p.write_text(html,encoding='utf-8')

p=Path('admin.js')
js=p.read_text(encoding='utf-8')
old="function filtered(){const q=searchInput.value.toLowerCase(),s=statusFilter.value;return players.filter(p=>(!s||(s==='drafted'?p.drafted:p.status===s))&&(`${p.full_name} ${p.district} ${p.primary_role} ${p.drafted_team||''}`.toLowerCase().includes(q)))}"
new="function filtered(){const q=searchInput.value.toLowerCase(),s=statusFilter.value,t=document.getElementById('tierFilter')?.value||'';return players.filter(p=>(!s||(s==='drafted'?p.drafted:p.status===s))&&(!t||(t==='unclassified'?!p.player_tier:p.player_tier===t))&&(`${p.full_name} ${p.district} ${p.primary_role} ${p.drafted_team||''}`.toLowerCase().includes(q)))}"
if old in js:
    js=js.replace(old,new,1)
js=js.replace("<td>${p.drafted?'Drafted':esc(p.status)}</td>\n<td><select id=\"team-${p.id}\">", "<td>${p.drafted?'Drafted':esc(p.status)}</td>\n<td><strong>${esc((p.player_tier||'Unclassified').toUpperCase())}</strong><br><button onclick=\"openTierAnalytics('${p.id}')\">Analyze</button></td>\n<td>${p.overall_player_score??p.cricheroes_score??'-'}</td>\n<td><select id=\"team-${p.id}\">",1)
js=js.replace('searchInput.oninput=renderTable;statusFilter.onchange=renderTable;', "searchInput.oninput=renderTable;statusFilter.onchange=renderTable;document.getElementById('tierFilter')?.addEventListener('change',renderTable);",1)
p.write_text(js,encoding='utf-8')
print('PASS: Player Tier Analytics installed. Public registration files were not changed.')
