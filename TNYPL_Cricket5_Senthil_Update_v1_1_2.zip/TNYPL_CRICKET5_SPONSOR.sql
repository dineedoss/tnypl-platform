DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.sponsors
    WHERE lower(name)=lower('Cricket5 Crickets Academy')
  ) THEN
    UPDATE public.sponsors
    SET logo_path='sponsor-cricket5.png',
        website_url=NULL,
        is_active=true
    WHERE lower(name)=lower('Cricket5 Crickets Academy');
  ELSE
    INSERT INTO public.sponsors
      (name,logo_path,website_url,display_order,is_active)
    VALUES
      ('Cricket5 Crickets Academy','sponsor-cricket5.png',NULL,
       COALESCE((SELECT max(display_order)+1 FROM public.sponsors),1),true);
  END IF;
END $$;

SELECT name,logo_path,website_url,display_order,is_active
FROM public.sponsors
WHERE lower(name)=lower('Cricket5 Crickets Academy');
