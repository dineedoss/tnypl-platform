#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

src = Path(__file__).resolve().parent
for f in ["index.html","sponsors.js","leadership.html","senthil-narayanan.html","styles.css"]:
    if not Path(f).exists():
        sys.exit(f"ERROR: {f} not found. Run from repository root.")

Path("assets/profiles").mkdir(parents=True, exist_ok=True)
shutil.copy2(src/"sponsor-cricket5.png", "sponsor-cricket5.png")
shutil.copy2(src/"assets/profiles/senthil-narayanan.png", "assets/profiles/senthil-narayanan.png")

p=Path("index.html")
s=p.read_text(encoding="utf-8")
if "Cricket5 Crickets Academy" not in s:
    marker = """      <div class="partner-card partner-card-open">
        <strong>Partner With TNYPL</strong>
        <span>Sponsor space available</span>
      </div>"""
    block = """      <div class="partner-card partner-card-logo">
        <img src="sponsor-cricket5.png" alt="Cricket5 Crickets Academy">
        <strong>Cricket5 Crickets Academy</strong>
        <span>Official Partner</span>
      </div>
"""
    if marker not in s:
        sys.exit("ERROR: homepage sponsor insertion point not found.")
    s=s.replace(marker,block+marker,1)
p.write_text(s,encoding="utf-8")

p=Path("sponsors.js")
s=p.read_text(encoding="utf-8")
if 'name:"Cricket5 Crickets Academy"' not in s:
    marker='{name:"Vedapile",logo_path:"sponsor-vedapile.png",website_url:"https://vedapile.com/"}'
    if marker not in s:
        sys.exit("ERROR: sponsors.js insertion point not found.")
    s=s.replace(marker, marker+',\n {name:"Cricket5 Crickets Academy",logo_path:"sponsor-cricket5.png"}', 1)
p.write_text(s,encoding="utf-8")

p=Path("leadership.html")
s=p.read_text(encoding="utf-8")
old='<a class="directory-profile" href="senthil-narayanan.html"><div class="profile-placeholder">SN</div>'
new='<a class="directory-profile" href="senthil-narayanan.html"><img src="assets/profiles/senthil-narayanan.png" alt="Senthil Narayanan">'
if old in s:
    s=s.replace(old,new,1)
s=s.replace("TNYPL · ttnypl@gmail.com","TNYPL · info@tnypl.in")
p.write_text(s,encoding="utf-8")

p=Path("senthil-narayanan.html")
s=p.read_text(encoding="utf-8")
old='<div class="profile-main-photo profile-placeholder">SN</div>'
new='<img class="profile-main-photo" src="assets/profiles/senthil-narayanan.png" alt="Senthil Narayanan">'
if old in s:
    s=s.replace(old,new,1)
s=s.replace("TNYPL · ttnypl@gmail.com","TNYPL · info@tnypl.in")
p.write_text(s,encoding="utf-8")

p=Path("styles.css")
s=p.read_text(encoding="utf-8")
css = """
.partner-card-logo img{
  display:block;
  width:min(220px,90%);
  height:88px;
  object-fit:contain;
  margin:0 auto 12px;
  background:#fff;
  border-radius:10px;
  padding:8px;
}
"""
if ".partner-card-logo img" not in s:
    s += "\n" + css
p.write_text(s,encoding="utf-8")

print("PASS: Cricket5 sponsor and Senthil photo update applied.")
