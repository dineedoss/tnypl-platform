TNYPL Cricket5 Sponsor + Senthil Photo Update v1.1.2

Adds Cricket5 Crickets Academy as an Official Partner and replaces Senthil
Narayanan's placeholder with the supplied photo.

Commands:

git checkout main
git pull origin main
git checkout -b hotfix/cricket5-senthil-assets

rm -rf /tmp/tnypl-cricket5-senthil
mkdir -p /tmp/tnypl-cricket5-senthil

unzip -o TNYPL_Cricket5_Senthil_Update_v1_1_2.zip -d /tmp/tnypl-cricket5-senthil

python3 /tmp/tnypl-cricket5-senthil/apply-cricket5-senthil.py

git diff -- index.html sponsors.js leadership.html senthil-narayanan.html styles.css
git status

If Sponsors page is database-backed, run TNYPL_CRICKET5_SPONSOR.sql in Supabase.

git add index.html sponsors.js leadership.html senthil-narayanan.html styles.css \
  sponsor-cricket5.png assets/profiles/senthil-narayanan.png

git commit -m "Add Cricket5 sponsor and Senthil Narayanan photo"

git push -u origin hotfix/cricket5-senthil-assets
