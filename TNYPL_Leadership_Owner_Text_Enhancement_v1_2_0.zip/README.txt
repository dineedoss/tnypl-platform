TNYPL Leadership & Franchise Owner Text Enhancement v1.2.0

TEXT-ONLY RELEASE.
No photographs, image paths, videos, CSS, JavaScript, registration flow,
auction flow or Supabase schema are changed.

DEPLOY

git checkout main
git pull origin main
git checkout -b release/v1.2-leadership-owner-content

rm -rf /tmp/tnypl-profile-text
mkdir -p /tmp/tnypl-profile-text

unzip -o TNYPL_Leadership_Owner_Text_Enhancement_v1_2_0.zip -d /tmp/tnypl-profile-text

python3 /tmp/tnypl-profile-text/apply-profile-text-enhancement.py

REVIEW

git diff --   dinesh-devadoss.html   senthil-narayanan.html   ranjith-janagiraman.html   ajay-manohar.html   leadership.html owners.html   vimalesh-vedachalam.html   gopi-ramadoss.html   porkai-pandian.html   satish-raja.html   ramanathan-periyaraja.html   pc-binny-jo.html   thanjavur-royals-owners.html   tuticorin-sharks-owners.html

PHOTO SAFETY CHECK

git diff | grep -E '^[+-].*(<img|src=|\.png|\.jpg|\.jpeg|\.webp)'

Expected: no output caused by this release.

COMMIT

git add   dinesh-devadoss.html   senthil-narayanan.html   ranjith-janagiraman.html   ajay-manohar.html   leadership.html owners.html   vimalesh-vedachalam.html   gopi-ramadoss.html   porkai-pandian.html   satish-raja.html   ramanathan-periyaraja.html   pc-binny-jo.html   thanjavur-royals-owners.html   tuticorin-sharks-owners.html

git commit -m "Expand leadership and franchise owner profiles"
git push -u origin release/v1.2-leadership-owner-content
