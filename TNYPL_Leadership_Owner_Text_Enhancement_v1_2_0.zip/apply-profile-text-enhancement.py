#!/usr/bin/env python3
from pathlib import Path
import json, sys

src = Path(__file__).resolve().parent
repls = json.loads((src/"replacements.json").read_text(encoding="utf-8"))
changed=[]

for fname, items in repls.items():
    p=Path(fname)
    if not p.exists():
        print(f"WARNING: {fname} not found; skipped.")
        continue
    s=p.read_text(encoding="utf-8")
    original=s
    for item in items:
        old,new=item["old"],item["new"]
        if new in s:
            continue
        if old not in s:
            print(f"WARNING: expected text not found in {fname}; one block skipped.")
            continue
        s=s.replace(old,new,1)
    s=s.replace("TNYPL · ttnypl@gmail.com","TNYPL · info@tnypl.in")
    s=s.replace("TNYPL · tnypl@gmail.com","TNYPL · info@tnypl.in")
    if s != original:
        p.write_text(s,encoding="utf-8")
        changed.append(fname)

print("Updated files:")
for f in changed:
    print(" -",f)
print(f"Total updated: {len(changed)}")
print("TEXT ONLY: this script does not modify images, image paths, CSS, JS, videos, or assets.")
